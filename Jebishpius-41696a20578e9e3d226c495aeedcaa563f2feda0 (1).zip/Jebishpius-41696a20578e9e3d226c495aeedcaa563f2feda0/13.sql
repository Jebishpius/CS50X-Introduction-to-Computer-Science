select p1.name from people p1 join stars s1 on s1.person_id = p1.id where s1.movie_id in (select stars.movie_id from people p
join stars on stars.person_id = p.id
join movies m on stars.movie_id = m.id
where p.name = 'Kevin Bacon'
and p.birth = 1958) and p1.name <> 'Kevin Bacon'