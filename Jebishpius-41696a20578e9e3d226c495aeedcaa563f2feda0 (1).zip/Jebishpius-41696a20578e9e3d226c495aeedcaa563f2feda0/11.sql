select title from movies m
join ratings r on r.movie_id = m.id
join stars on stars.movie_id = m.id
join people on stars.person_id = people.id
where name = 'Chadwick Boseman' order by r.rating desc
limit 5