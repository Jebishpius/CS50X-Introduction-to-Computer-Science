select title from movies m
join stars on stars.movie_id = m.id
join people on stars.person_id = people.id
where (name = 'Johnny Depp')
intersect
select title from movies m
join stars on stars.movie_id = m.id
join people on stars.person_id = people.id
where (name = 'Helena Bonham Carter')